/*
* JANGAN UBAH-UBAH INFO!!!
* "JANGAN MODAL NAMA DOANG BRO!!!"
* SCRIPT BY ADAM RAIS ID
* JANGAN MODAL NAMA DOANG BOSQ
* HARGAILAH YY MEMBUAT SCRIPT INI BOSQ
* JANGAN UBAH-UBAH INFO!!!
* ADAM RAIS ID
* BOLEH UBAH TAPI KECUALI INFO!!!
*/
const A187 = '👾ADAM👾'; // JANGAN UBAH-UBAH INFO!!!
const instagram = 'https://instagram.com/adamrais.h'; // JANGAN UBAH-UBAH INFO!!!
const nomer = 'Wa.me/+6285277030729'; // JANGAN UBAH-UBAH INFO!!!
const aktif = 'Tergantung jaringan'; // JANGAN UBAH-UBAH INFO!!!
const groupwhatsapp = 'https://chat.whatsapp.com/'; // JANGAN UBAH-UBAH INFO!!!
const youtube = 'https://www.youtube.com/channel/'; // JANGAN UBAH-UBAH INFO!!!
//A187ID
const qrcode = require("qrcode-terminal");
const moment = require("moment");
const cheerio = require("cheerio");
const get = require('got')
const fs = require("fs");
const dl = require("./lib/downloadImage.js");
const fetch = require('node-fetch');
const urlencode = require("urlencode");
const axios = require("axios");
const imageToBase64 = require('image-to-base64');
const aris = require("./lib/aris.js");
const donate = require("./lib/donate.js");
const info = require("./lib/info.js");
const aris1 = require("./lib/aris1.js");
const { color, bgcolor } = require("./lib/color.js");
const { getBuffer, fetchJson } = require("./lib/fetcher.js");
const readTextInImage = require('./lib/ocr')
//A187ID
const
{
   WAConnection,
   MessageType,
   Presence,
   MessageOptions,
   Mimetype,
   WALocationMessage,
   WA_MESSAGE_STUB_TYPES,
   ReconnectMode,
   ProxyAgent,
   mentionedJid,
   waChatKey,
} = require("@adiwajshing/baileys");
var jam = moment().format("HH:mm");


function foreach(arr, func)
{
   for (var i in arr)
   {
      func(i, arr[i]);
   }
}
const conn = new WAConnection()
conn.on('qr', qr =>
{
   qrcode.generate(qr,
   {
      small: true
   });
   console.log(`[ ${moment().format("HH:mm:ss")} ] ADAMBOT ready scan now!`);
});


conn.on('credentials-updated', () =>
{
   // save credentials whenever updated
   console.log(`credentials updated$`)
   const authInfo = conn.base64EncodedAuthInfo() // get all the auth info we need to restore this session
   fs.writeFileSync('./session.json', JSON.stringify(authInfo, null, '\t')) // save this info to a file
})
fs.existsSync('./session.json') && conn.loadAuthInfo('./session.json')
// uncomment the following line to proxy the connection; some random proxy I got off of: https://proxyscrape.com/free-proxy-list
//conn.connectOptions.agent = ProxyAgent ('http://1.0.180.120:8080')
conn.connect();

conn.on('group-participants-update', async (anu) => {
		try {
			const mdata = await conn.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				try {
					ppimg = await conn.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Selamat datang di group *${mdata.subject}*\n\nSemoga Nyaman di grup ini`
				let buff = await getBuffer(ppimg)
				conn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks})
			} else if (anu.action == 'remove') {
				try {
					ppimg = await conn.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `Selamat Tinggal\n\nSemoga anda Kembali lagi`
				let buff = await getBuffer(ppimg)
				conn.sendMessage(mdata.id, buff, MessageType.image, {caption: teks})
			}
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})


conn.on('user-presence-update', json => console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by @adamrais.h`))
conn.on('message-status-update', json =>
{
   const participant = json.participant ? ' (' + json.participant + ')' : '' // participant exists when the message is from a group
   console.log(`[ ${moment().format("HH:mm:ss")} ] => bot by @adamrais.h`)
})

conn.on('message-new', async(m) =>
{
   const vh = 'VCGF8885200huuutarw'
   const messageContent = m.message
   const text = m.message.conversation
   let id = m.key.remoteJid
   const from = m.key.remoteJid
   const messageType = Object.keys(messageContent)[0] // message will always contain one key signifying what kind of message
   let imageMessage = m.message.imageMessage;
   console.log(`[ ${moment().format("HH:mm:ss")} ] => Nomor: [ ${id.split("@s.whatsapp.net")[0]} ] => ${text}`);
   
   const ownerNumber = ["6285277030729@s.whatsapp.net"] // replace this with your number
const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? m.participant : m.key.remoteJid
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes("6282360905584@s.whatsapp.net") || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const groupDesc = isGroup ? groupMetadata.desc : ''
const isOwner = ownerNumber.includes(sender)
   
   //GroupsA187ID

if (text.includes("!buatgrup"))
   {
var nama = text.split("!buatgrup")[1].split("-nomor")[0];
var nom = text.split("-nomor")[1];
var numArray = nom.split(",");
for ( var i = 0; i < numArray.length; i++ ) {
    numArray[i] = numArray[i] +"@s.whatsapp.net";
}
var str = numArray.join("");
console.log(str)
const group = await conn.groupCreate (nama, str)
console.log ("created group with id: " + group.gid)
conn.sendMessage(group.gid, "hello everyone", MessageType.extendedText) // say hello to everyone on the group

}

// FFA187ID
if(text.includes("!cek")){
var num = text.replace(/!cek /, "")
var idn = num.replace("0","+62");

console.log(id);
const gg = idn+'@s.whatsapp.net'

const exists = await conn.isOnWhatsApp (gg)
console.log(exists);
conn.sendMessage(id ,`${gg} ${exists ? " exists " : " does not exist"} on WhatsApp`, MessageType.text)
}

//ChatA187ID
else if (text == 'assalamualaikum'){
conn.sendMessage(id, ' _3aalaikumsalam, _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'salam'){
conn.sendMessage(id, ' _Waalaikumsalam, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'asalamualaikum'){
conn.sendMessage(id, ' _Waalaikumsalam, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Assalamualaikum'){
conn.sendMessage(id, ' _Waalaikumsalam, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'p'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'P'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Halo'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Asu'){
conn.sendMessage(id, 'Lu Asw' ,MessageType.text, { quoted: m });
}
else if (text == 'Asw'){
conn.sendMessage(id, 'Lu Asw' ,MessageType.text, { quoted: m });
}
else if (text == '#owner'){
conn.sendMessage(id, ' *Owner ADAM wa.me/+6285277030729* ' ,MessageType.text, { quoted: m });
}
else if (text == '#help'){
conn.sendMessage(id, ' *Menampilkan Pilihan Menu!!!* ' ,MessageType.text, { quoted: m });
}
else if (text == '#menu'){
conn.sendMessage(id, ' *Menampilkan Fitur Menu!!!* ' ,MessageType.text, { quoted: m });
}
else if (text == '#info'){
conn.sendMessage(id, ' *Menampilkan Info!!!* ' ,MessageType.text, { quoted: m });
}
else if (text == '#donasi'){
conn.sendMessage(id, ' *Menampilkan Donasi!!!* ' ,MessageType.text, { quoted: m });
}
else if (text == '#creator'){
conn.sendMessage(id, ' *Creator ADAM wa.me/+6285277030729* ' ,MessageType.text, { quoted: m });
}
else if (text == 'Pagi'){
conn.sendMessage(id, ' _Pagi juga, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Siang'){
conn.sendMessage(id, ' _Siang juga, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Sore'){
conn.sendMessage(id, ' _Sore juga, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Malam'){
conn.sendMessage(id, ' _Malam juga, Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Ngentod'){
conn.sendMessage(id, 'Pengin ngentod? babi looo' ,MessageType.text, { quoted: m });
}
else if (text == 'Anjing'){
conn.sendMessage(id, 'Jangan toxic anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Babi'){
conn.sendMessage(id, 'Jangan toxic anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Kontol'){
conn.sendMessage(id, 'Jangan toxic anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Pepek'){
conn.sendMessage(id, 'Jangan toxic anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Ktl'){
conn.sendMessage(id, 'Kalo toxic jangan disingkat anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Ppk'){
conn.sendMessage(id, 'Kalo toxic jangan disingkat anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Ajg'){
conn.sendMessage(id, 'Kalo toxic jangan disingkat anjing,kntl,babi,monyet' ,MessageType.text, { quoted: m });
}
else if (text == 'Bacot'){
conn.sendMessage(id, ' *lu bacot_-* ' ,MessageType.text, { quoted: m });
}
else if (text == 'Test'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Hai'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Woi'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Eoy'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Hi'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Gan'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Sis'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Bro'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Min'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Sayang'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'I love u'){
conn.sendMessage(id, ' _love you too😻_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Mas'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Mba'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Bre'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Cuy'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Euy'){
conn.sendMessage(id, ' _Iyah aku disini kak...ada yang bisa kami bantu? Ketik *#menu* untuk melihat fitur bot kami🙏_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'makasi'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Makasi'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'makasih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Makasih'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'thank'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Thank'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'thanks'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == 'Thanks'){
conn.sendMessage(id, ' _Sama sama, semoga harimu menyenangkan :)_ ' ,MessageType.text, { quoted: m });
}
else if (text == '!pesankosong'){
conn.sendMessage(id, '͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏' ,MessageType.text, { quoted: m });
}
// FiturA187ID

if (text.includes('!nulis')){
  var aris = text.replace(/!nulis /, '')
    axios.get('https://arugaz.herokuapp.com/api/nulis?text='+aris)
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] WAIT BOT SEDANG NULIS', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}

if (text.includes("!tts")){
const teks = text.replace(/!tts /, "")
const gtts = (`https://rest.farzain.com/api/tts.php?id=${teks}&apikey=O8mUD3YrHIy9KM1fMRjamw8eg`)
    conn.sendMessage(id, gtts ,MessageType.text, { quoted: m });
}

if (text.includes("!jam")){
const adam = text.replace(/!jam /, "")
axios.get(`https://rest.farzain.com/api/jam.php?id=${adam}&apikey=e5a6CtIFd4ACxYzMKT76t5rkW`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = `*Nih Jam ${adam} kak* \n\n* Tanggal:* ${res.data.time.date}\n* Waktu :* ${res.data.time.time}\n* Tempat :* ${res.data.location.address}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes('!surah')){
    var gh = text.split("!surah ")[1];
    var teks1 = gh.split("|")[0];
    var teks2 = gh.split("|")[1];
    axios.get(`https://api.banghasan.com/quran/format/json/surat/${teks1}/ayat/${teks2}`).then((res) => {
        const sr = /{(.*?)}/gi;
        const hs = res.data.surat.ayat;
        const ket = `${hs}`.replace(sr, '');
        let hasil = `[${ket}]   ${res.ayat.data.ar.teks}\n\n${res.ayat.data.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
        conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
    })
}

if (text.includes('!ytmp3')){
  var teks = text.replace(/!ytmp3 /, '')
    axios.get('https://api.vhtear.com/ytmp3?query=${teks}&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.image)
        .then(
          (ress) => {
            let hasil = `*Judul:* ${res.data.result.title}\n\n *Size:* ${res.data.result.size}\n\n *Audio:* ${res.data.result.mp3}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes('!spek kereta')){
  var teks = text.replace(/!spek kereta /, '')
    axios.get('https://api.vhtear.com/infomotor?merk=${teks}&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.image)
        .then(
          (ress) => {
            let hasil = `*Nama Kereta:* ${res.data.result.title}\n *Harga:* ${res.data.result.harga}\n *Spesifikasi:* ${res.data.result.spesifikasi}\n *Kelebihan:* ${res.data.result.kelebihan}\n *Kekurangan:* ${res.data.result.kekurangan}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes('!spek mobil')){
  var teks = text.replace(/!spek mobil /, '')
    axios.get('https://api.vhtear.com/infomobil?merk=${teks}&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.image)
        .then(
          (ress) => {
            let hasil = `*Nama Mobil:* ${res.data.result.title}\n *Harga:* ${res.data.result.harga}\n *Spesifikasi:* ${res.data.result.spesifikasi}\n *Kelebihan:* ${res.data.result.kelebihan}\n *Kekurangan:* ${res.data.result.kekurangan}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes('!spek hp')){
  var teks = text.replace(/!spek hp /, '')
    axios.get('https://api.vhtear.com/gsmarena?query=${teks}&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.image)
        .then(
          (ress) => {
            let hasil = `*Nama Hp:* ${res.data.result.title}\n *Data:* ${res.data.result.spec}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}

if (text.includes('!resep')){
  var teks = text.replace(/!resep /, '')
    axios.get('https://api.vhtear.com/resepmasakan?query=${teks}&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.image)
        .then(
          (ress) => {
            let hasil = `*Nama Masakan:* ${res.data.result.title}\n *Desc:* ${res.data.result.desc}\n *Bahan:* ${res.data.result.bahan}\n *Cara:* ${res.data.result.cara}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}

if (text.includes('!igstalk')){
  var teks = text.replace(/!igstalk /, '')
    axios.get('https://arugaz.herokuapp.com/api/stalk?username='+teks)
    .then((res) => {
      imageToBase64(res.data.Profile_pic)
        .then(
          (ress) => {
           let hasil = `User Ditemukan!!\n\n* Nama :* ${res.data.Name}\n* Username :* ${res.data.Username}\n* Followers :* ${res.data.Jumlah_Followers}\n* Mengikuti :* ${res.data.Jumlah_Following}\n* Jumlah Post :* ${res.data.Jumlah_Post}\n* Bio :* ${res.data.Biodata}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}

if (text.includes('!tiktok')){
  var teks = text.replace(/!tiktok /, '')
    axios.get('https://api.vhtear.com/tiktokprofile?query=${teks}&apikey=VCGF8885200huuutarw')
    .then((res) => {
      imageToBase64(res.data.result.picture)
        .then(
          (ress) => {
           let hasil = `User Ditemukan!!\n\n* Nama :* ${res.data.result.title}\n* Username :* ${res.data.result.username}\n* Followers :* ${res.data.result.follower}\n* Mengikuti :* ${res.data.result.follow}\n* Jumlah Post :* ${res.data.result.video_post}\n* Jumlah Like :* ${res.data.result.like_count}\n* Bio :* ${res.data.result.bio}\n* Link Tiktod :* ${res.data.result.url_account}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}

if (text.includes("!heroml")) {
	
	const teks = text.replace(/!heroml /, "")
	axios.get(`https://api.vhtear.com/herodetail?query=${teks}&apikey=${vh}`).then(async (res) => {
		imageToBase64(res.data.result.pictHero)
  .then(
  (response) => {
	  conn.sendMessage(id, '[WAIT]Sedang Mencari Hero ml yang anda cari', MessageType.text)
  	var buf = Buffer.from(response, 'base64'); 
 let hasil = `*Nama Hero:*\n ${res.data.result.title}\n\n*Info Hero:*\n ${res.data.result.info}\n*Status Hero:* ${res.data.result.attributes}`
conn.sendMessage(id, buf ,MessageType.image, {caption: hasil, quoted: m})
})
})
}

if (text.includes('!infogempa')){
    axios.get(`https://st4rz.herokuapp.com/api/infogempa`).then((res) => {
      imageToBase64(res.data.map)
        .then(
          (ress) => {
          let hasil = `*INFO GEMPA TERBARU DI INDONESIA*\n\n* Pusat Gempa :* ${res.data.lokasi}\n* Koordinat :* ${res.data.koordinat}\n* Waktu :* ${res.data.waktu}\n* Magnitudo :* ${res.data.magnitude}\n* Kedalaman :* ${res.data.kedalaman}\n* Potensi :* ${res.data.potensi}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}
if (text.includes("!chord")){
const aris = text.replace(/!chord /, "")
axios.get(`https://alfians-api.herokuapp.com/api/chord?q=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = `*Nih Cord Lagu ${aris} kak* \n\nCord: _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}


if (text.includes("!ytmp4")){
const aris = text.replace(/!ytmp4 /, "")
axios.get(`https://alfians-api.herokuapp.com/api/ytv?url=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Judul:* ${res.data.title}\n\n *Tipe:* ${res.data.ext}\n\n *Resolution:* ${res.data.resolution}\n\n *Zize:* ${res.data.filesize}\n\n *Video:* ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!brainly")){
const data = text.replace(/!brainly /, "")
axios.get(`https://api.vhtear.com/branly?query=${data}&apikey=${vh}`).then((res) => {
	conn.sendMessage(id, 'WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Jawaban:* ${res.data.result.data}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!infoAlamat")){
const data = text.replace(/!infoAlamat /, "")
axios.get(`https://api.vhtear.com/infoalamat?query=${data}&apikey=${vh}`).then((res) => {
	conn.sendMessage(id, 'WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Data:* ${res.data.result.data}\n*Keterangan:* ${res.data.result.deskripsi}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes("!ramalanZodiak")){
const data = text.replace(/!ramalanZodiak /, "")
axios.get(`https://api.vhtear.com/zodiak?query=${data}&apikey=${vh}`).then((res) => {
	conn.sendMessage(id, 'WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *zodiak:* ${res.data.result.zodiak}\n*Ramalan:* ${res.data.result.ramalan}\n*Nomor Hoki:* ${res.data.result.nomorKeberuntungan}\n*Motivasi:* ${res.data.result.motivasi}\n*Inspirasi:* ${res.data.result.inspirasi}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes("!twt")){
const aris = text.replace(/!twt /, "")
axios.get(`https://mhankbarbar.herokuapp.com/api/twit?url=${aris}&apiKey=zFuV88pxcIiCWuYlwg57`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = `âœ…Berhasil$ silahkan klik link di bawah untuk mendownload hasilnya$\nKlik link dibawahðŸ—¡ï¸\n\nSize: ${res.data.filesize}\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}


if (text.includes("!fb")){
const aris = text.replace(/!fb /, "")
axios.get(`https://arugaz.herokuapp.com/api/fb?url=${aris}`).then((res) => {
    let hasil = `Nih BosQ Pilih...\n\n *Revolusi SD*: ${res.data.result.sd}\n\n *Rovolusi HD:* ${res.data.result.hd}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}

  if (text.includes("!provider"))
  {
  axios.get(`http://ip-api.com/json/`).then((res) =>{ 
  let hasil = `➸ *Negara* : ${res.data.country}\n*Region(Daerah)* : ${res.data.regionName}\n*Kota* : ${res.data.city}\n*Nama Perusahaan Provider* : ${res.data.as}\n*Waktu Penggunaan Di* : ${res.data.timezone}\n*Query (Ip Address)* : ${res.data.query}` 
  conn.sendMessage(id, hasil, MessageType.text); 
 })
 }
   if (text.includes("!ip"))
  {
  axios.get(`https://api.myip.com/`).then((res) =>{ 
  let hasil = `➸ *Negara* : ${res.data.country}\n*Ip Address* : ${res.data.ip}` 
  conn.sendMessage(id, hasil, MessageType.text); 
 })
 }
 if (text.includes("!quotes anime"))
  {
  axios.get(`http://melodicxt.herokuapp.com/api/get/anime-quotes?apiKey=administrator/`).then((res) =>{ 
  let hasil = `➸ *Anime* : ${res.data.anime}\n*Hero* : ${res.data.chara}\n*Quotes* : ${res.data.quote}` 
  conn.sendMessage(id, hasil, MessageType.text); 
 })
 }
 
   if (text.includes("!checkip"))
  { const aris = text.replace(/!checkip /, "") 
  axios.get(`https://mnazria.herokuapp.com/api/check?ip=${aris}`).then((res) =>{ 
  let hasil = `➸ *City* : ${res.data.city}\n*Latitude* : ${res.data.latitude}\n*Longtitude* : ${res.data.longitude}\n*Region* : ${res.data.region_name}\n*Region Code* : ${res.data.region_code}\n*IP* : ${res.data.ip}\n*Type* : ${res.data.type}\n*Name* : ${res.data.name}\n*zip* : ${res.data.zip}\n*Geonime* : ${res.data.location.geoname_id}\n*Capital* : ${res.data.location.capital}\n*Calling* : ${res.data.location.calling_code}\n\n*Country Flag* : ${res.data.location.country_flag}\n\n*CountryFlagEmoji* : ${res.data.location.country_flag_emoji}` 
  conn.sendMessage(id, hasil, MessageType.text); 
 })
 }
 
if (text.includes("!family100")) {
	const teks = text.replace(/!family100 /, "")
axios.get(`https://api.vhtear.com/family100&apikey=VCGF8885200huuutarw`).then((res) => {
    let hasil = `*Soal :* ${res.data.result.soal}`;
    conn.sendMessage(id, hasil ,MessageType.text);
    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 10 Detik` ,MessageType.text);
    }, 30000)
    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 20 Detik` ,MessageType.text);
    }, 20000)
	    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 30 Detik` ,MessageType.text);
    }, 10000)
     setTimeout( () => {
    let asw = `*Jawaban:* ${res.data.result.jawaban}`;
    conn.sendMessage(id, asw , MessageType.text);
	      }, 40000)
})
} 
 
 if (text.includes("!tebak")) {
	const teks = text.replace(/!tebak /, "")
axios.get(`https://api.vhtear.com/funkuis&apikey=${vh}`).then((res) => {
    let hasil = `Soal: ${res.data.result.soal}`;
    conn.sendMessage(id, hasil ,MessageType.text);
    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 10 Detik` ,MessageType.text);
    }, 30000)
    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 20 Detik` ,MessageType.text);
    }, 20000)
	    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 30 Detik` ,MessageType.text);
    }, 10000)
     setTimeout( () => {
    let asw = `Jawaban: ${res.data.result.jawaban}\n\nSebab: ${res.data.result.desk}`;
    conn.sendMessage(id, asw , MessageType.text);
	      }, 40000)
})
}
 if (text.includes('!map')){
  var aris = text.replace(/!map /, '')
    axios.get('https://mnazria.herokuapp.com/api/maps?search='+aris)
    .then((res) => {
      imageToBase64(res.data.gambar)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text, { quoted: m })
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}  
 if (messageType == 'imageMessage')
   {
       let caption = imageMessage.caption.toLocaleLowerCase()
       if (caption == '!ocr')
       {
           const img = await conn.downloadAndSaveMediaMessage(m)
           readTextInImage(img)
               .then(data => {
                   console.log(data)
                   conn.sendMessage(id, `${data}`, MessageType.text);
               })
               .catch(err => {
                   console.log(err)
               })
       }
   }
  if (text.includes('!waifu')){
  var aris = text.replace(/!waifu /, '')
    axios.get('https://st4rz.herokuapp.com/api/waifu')
    .then((res) => {
      imageToBase64(res.data.image)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}
   if (text.includes("!quotes1")){
 var aris = text.replace(/ /, '')
axios.get(`https://arugaz.herokuapp.com/api/randomquotes`).then((res) => {
    let hasil = `➸  *Author : ${res.data.author}*\n\n\n➸${res.data.quotes}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
if (text.includes("!renungan")){
const teks = text.replace(/!renungan /, "")
axios.get(`https://docs-jojo.herokuapp.com/api/renungan`).then((res) => {
    let hasil = `Isi : ${res.data.Isi} \njudul : ${res.data.judul} \npesan : ${res.data.pesan}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}  
if (text.includes("!alkitab")){
const teks = text.replace(/!alkitab /, "")
axios.get(`https://docs-jojo.herokuapp.com/api/alkitab`).then((res) => {
    let hasil = `ayat : ${res.data.result.ayat} \nisi : ${res.data.result.isi} \nlink : ${res.data.result.link}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}  
    if (text.includes("!puisi1")){
 var aris = text.replace(/ /, '')
axios.get(`https://arugaz.herokuapp.com/api/puisi1`).then((res) => {
    let hasil = `➸ ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
 if (text.includes("!puisi2")){
 var aris = text.replace(/ /, '')
axios.get(`https://arugaz.herokuapp.com/api/puisi2`).then((res) => {
    let hasil = `➸ ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
  if (text.includes("!puisi3")){
 var aris = text.replace(/ /, '')
axios.get(`https://arugaz.herokuapp.com/api/puisi3`).then((res) => {
    let hasil = ` ➸ ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
 if (text.includes('!nekonime')){
    axios.get('https://arugaz.herokuapp.com/api/nekonime')
    .then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text, { quoted: m })
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}
 if (text.includes('!ssweb')){
 	const teks = text.replace(/!ssweb /, '')
    axios.get('http://melodicxt.herokuapp.com//api/ssweb?url=${teks}&apiKey=administrator')
    .then((res) => {
      imageToBase64(res.data.result.result)
        .then(
          (ress) => {
            conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text, { quoted: m })
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}

if (text.includes("!say")){
  const teks = text.replace(/!say /, "")
conn.sendMessage(id, teks, MessageType.text, { quoted: m })
}

if (text.includes('!ttp')){
  var teks = text.replace(/!ttp /, '')
    axios.get(`https://mhankbarbars.herokuapp.com/api/text2image?text=${teks}&apiKey=N2Ws9kp3KTDYtry5Jjyz`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
}
if (text.includes("!ping")){
const aris = text.replace(/!ping /, "")
axios.get(`https://api.banghasan.com/domain/nping/${aris}`).then((res) => {
    let hasil = `*query : ${res.data.query}*\n\nhasil : ${res.data.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
  if (text.includes("!hostsearch")){
const aris = text.replace(/!hostsearch /, "")
axios.get(`https://api.banghasan.com/domain/hostsearch/${aris}`).then((res) => {
    let hasil = `*query : ${res.data.query}*\n\nhasil : ${res.data.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
  })
 }
 if (text.includes("!zodiak")){
const aris = text.replace(/!zodiak /, "")
axios.get(`https://arugaz.herokuapp.com/api/getzodiak?nama=aruga&tgl-bln-thn=${aris}`).then((res) => {
    let hasil = `➡️ Lahir : ${res.data.lahir}*\n➡ ️ultah : ${res.data.ultah}\n➡ ️usia : ${res.data.usia}\n➡ zodiak : ${res.data.zodiak}️`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
    if (text.includes("!bts"))
   {
    var items = ["foto bts", "bts kpop"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
    if (text.includes("!find"))
   {
    var items = text.replace(/!find /, '')
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }
if (text.includes("!meme"))
   {
    var items = ["funny meme", "meme", "meme 2020"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }      
if (text.includes("!husbu"))
   {
    var items = ["husbu", "husbu karma"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

if (text.includes("!dragon ball"))
   {
    var items = ["anime dragon ball"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }    
    
    if (text.includes("!shota"))
   {
    var items = ["anime shota", "shota"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }    
    
    if (text.includes("!party")) {
	
  	const teks = text.replace(/!party /, "")
  imageToBase64(`https://api.vhtear.com/partytext?text=${teks}&apikey=${vh}`)
  .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}
if (text.includes("!glow")) {
	
  	const teks = text.replace(/!glow /, "")
  imageToBase64(`https://api.vhtear.com/glowtext?text=${teks}&apikey=${vh}`)
  .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}    

if (text.includes("!thunder")) {
	
  	const teks = text.replace(/!thunder /, "")
  imageToBase64(`https://api.vhtear.com/thundertext?text=${teks}&apikey=${vh}`)
  .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}    

if (text.includes('!gltext')){
var gh = text.split("!gltext ")[1];
    var teks1 = gh.split("|")[0];
    var teks2 = gh.split("|")[1];
    imageToBase64(`https://api.vhtear.com/glitchtext?text1=${teks1}&text2=${teks2}&apikey=VCGF8885200huuutarw`)
    .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}    

if (text.includes("!tahta")) {
	
  	const teks = text.replace(/!tahta /, "")
  imageToBase64(`https://api.vhtear.com/hartatahta?text=${teks}&apikey=${vh}`)
  .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}    

if (text.includes("!galaxy")) {
	
  	const teks = text.replace(/!galaxy /, "")
  imageToBase64(`https://api.vhtear.com/galaxytext?text=${teks}&apikey=${vh}`)
  .then(
  (response) => {
  	var buf = Buffer.from(response, 'base64'); 
conn.sendMessage(id, buf , MessageType.image, {caption: "Ini kakak", quoted: m})
})
}        
    
    if (text.includes("!exo"))
   {
    var items = ["foto exo", "exo"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }    
    
    if (text.includes("!bpink"))
   {
    var items = ["foto blackpink", "blackpink"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }    
    
    if (text.includes("!twice"))
   {
    var items = ["foto twice", "twice"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }    
    
        if (text.includes("!red velvet"))
   {
    var items = ["foto idol red velvet", " idol red velvet"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }    
    
     if (text.includes("!covidcountry")){
const aris = text.replace(/!covidcountry /, "")
axios.get(`https://arugaz.herokuapp.com/api/corona?country=${aris}`).then((res) => {
    let hasil = `Negara : ${res.data.result.country}\n\nActive : ${res.data.result.active}\ncasesPerOneMillion : ${res.data.result.casesPerOneMillion}\ncritical : ${res.data.result.critical}\ndeathsPerOneMillion : ${res.data.result.deathsPerOneMillion}\nrecovered : ${res.data.result.recovered}\ntestPerOneMillion : ${res.data.result.testPerOneMillion}\ntodayCases : ${res.data.result.todayCases}\ntodayDeath : ${res.data.result.todayDeath}\ntotalCases : ${res.data.result.totalCases}\ntotalTest : ${res.data.result.totalTest}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
 if (text.includes("!jadwalTVnow")){
axios.get(`https://docs-jojo.herokuapp.com/api/jadwaltvnow`).then((res) => {
    let hasil = `Jam : ${res.data.result.jam}\n\n${res.data.result.jadwalTV}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
      if (text.includes("!jadwalfilm")){
const teks = text.replace(/!jadwalfilm /, "")
axios.get(`http://melodicxt.herokuapp.com//api/jadwaltv?query=${teks}&apiKey=administrator`).then((res) => {
    let hasil = `Film yang akan tayang di saluran ${teks} : ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
 
 if (text.includes("$")){
const teks = text.replace(/$ /, "")
axios.get(`https://st4rz.herokuapp.com/api/simsimi?kata=${teks}`).then((res) => {
    let hasil = `${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
 if (text.includes("!kbbi")){
const aris = text.replace(/!kbbi /, "")
axios.get(`https://tobz-api.herokuapp.com/api/kbbi?kata=${aris}`).then((res) => {
    let hasil = `${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
 
  if (text.includes("!cuaca")){
const teks = text.replace(/!cuaca /, "")
axios.get(`http://melodicxt.herokuapp.com//api/cuaca?query=${teks}&apiKey=administrator`).then((res) => {
    let hasil = `*tempat:* ${res.data.result.tempat}\nCuaca: ${res.data.result.cuaca}\nAngin: ${res.data.result.angin}\nSuhu: ${res.data.result.suhu}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
  })
 }
 
 if (text.includes('!blackpink')){
  var teks = text.replace(/!blackpink /, '')
    axios.get(`https://docs-jojo.herokuapp.com/api/blackpink?text=${teks}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
} 
if (text.includes('!animecry')){
  var teks = text.replace(/!animecry /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/cry`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}

if (text.includes('!animehug')){
  var teks = text.replace(/!animehug /, '')
    axios.get(`https://tobz-api.herokuapp.com/api/hug`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}

if (text.includes('!phub')){
var porn = text.split("!phub ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://mhankbarbars.herokuapp.com/api/textpro?theme=pornhub&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[ WAIT ] Sedang diproses silahkan tunggu sebentar', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { quoted: m });
        })
    })
}

if (text.includes('!wolf')){
var porn = text.split("!wolf ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://tobz-api.herokuapp.com/api/textpro?theme=wolflogo1&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[ WAIT ] Sedang diproses silahkan tunggu sebentar', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { quoted: m });
        })
    })
}

if (text.includes('!wolf2')){
var porn = text.split("!wolf2 ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://tobz-api.herokuapp.com/api/textpro?theme=wolflogo2&text1=${teks1}&text2=${teks2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[ WAIT ] Sedang diproses silahkan tunggu sebentar', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { quoted: m });
        })
    })
}

if (text.includes('!lion')){
var porn = text.split("!lion ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://tobz-api.herokuapp.com/api/textpro?theme=lionlogo&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[ WAIT ] Sedang diproses silahkan tunggu sebentar', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { quoted: m });
        })
    })
}

if (text.includes("!grupinfo")) {
				conn.updatePresence(from, Presence.composing)
				if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , {quoted: m})
					try {
					ppimg = await conn.getProfilePicture(from)
				} catch {
					ppimg = 'https://i.ibb.co/NthF8ds/IMG-20201223-WA0740.jpg'
				}
					let buf = await getBuffer(ppimg)
					var teks = `*Nama grup :* ${groupName}\n*Deskripsi :* ${groupDesc}\n*Jumlah Admin :* ${groupAdmins.length}\n*Jumlah Member :* ${groupMembers.length}`
					conn.sendMessage(from, buf, MessageType.image, {quoted: m, caption: teks})
}
if (text.includes("!gcinfo")) {
                conn.updatePresence(from, Presence.composing)
                if (!isGroup) return conn.sendMessage(id, "Ini Bukan Grup Bodo!", MessageType.text , {quoted: m})
                ppUrl = await conn.getProfilePicture(from) // leave empty to get your own
			   var buff = await getBuffer(ppUrl)
		        conn.sendMessage(from, buff, MessageType.image, {quoted: m, caption: `*NAME* : ${groupName}\n*MEMBER* : ${groupMembers.length}\n*ADMIN* : ${groupAdmins.length}\n*DESK* : ${groupDesc}`})
              }

if (text.includes("!report")) {
const teks = text.replace(/!report /, "")
const hasil = `${id.split("@s.whatsapp.net")[0]}`;
var nomor = m.participant
    const bug = {
          text: `[BUG REPORT]\n\n*Nomor :* @${nomor.split("@s.whatsapp.net")[0]}\n*Id :* ${hasil}\n*Pesan :* ${teks}`,
          contextInfo: { mentionedJid: [nomor] }
    }
conn.sendMessage('6282360905584@s.whatsapp.net', bug, MessageType.text, { quoted: m })
conn.sendMessage(id, 'Masalah telah di laporkan ke owner BOT, laporan palsu/main2 tidak akan ditanggapi.', MessageType.text, { quoted: m } )
         
}

if (text.includes("!tebakgambar")) {
  const teks = text.replace(/!tebakgambar /, "")
    axios.get('https://api.vhtear.com/tebakgambar&apikey=${vh}')
    .then((res) => {
      imageToBase64(res.data.result.soalImg)
        .then(
          (ress) => {
		  var buf = Buffer.from(ress, 'base64')
   conn.sendMessage(id, buf, MessageType.image, { caption: "Jawab Dalam 30 detik", quoted: m })
    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 10 Detik` ,MessageType.text);
    }, 20000)
	    setTimeout( () => {
    conn.sendMessage(id, `Sisa Waktu : 20 Detik` ,MessageType.text);
    }, 10000)
     setTimeout( () => {
           let hasil = `*Jawaban :* ${res.data.result.jawaban}`;
            conn.sendMessage(id, hasil, MessageType.text, { caption: hasil, quoted: m })
			}, 30000)
        })
    })
}

if (text.includes('!ninja')){
var porn = text.split("!ninja ")[1];
    var text1 = porn.split("|")[0];
    var text2 = porn.split("|")[1];
    axios.get(`https://tobz-api.herokuapp.com/api/textpro?theme=ninjalogo&text1=${text1}&text2=${text2}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, '[ WAIT ] Sedang diproses silahkan tunggu sebentar', MessageType.text, { quoted: m })
            conn.sendMessage(id, buf, MessageType.image, { quoted: m });
        })
    })
}

if (text.includes('!gaming')){
  var teks = text.replace(/!gaming /, '')
    axios.get(`https://docs-jojo.herokuapp.com/api/gaming?text=${teks}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}

if (text.includes('!ramalanJodoh')){
var gh = text.split("!ramalanJodoh ")[1];
    var teks1 = gh.split("-")[0];
    var teks2 = gh.split("-")[1];
    var teks3 = gh.split("-")[2];
    axios.get(`https://api.vhtear.com/harijadian?tgl=${teks1}&bln=${teks2}&thn=${teks3}&apikey=${vh}`).then((res) => {
    let hasil = `✅Hasil Ramalan: ${res.data.result.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text);
    })
}

if (text.includes("!ig")){
const aris = text.replace(/!ig /, "")
axios.get(`https://alfians-api.herokuapp.com/api/ig?url=${aris}`).then((res) => {
    let hasil = `✅Dwonload sendiri link error maaf\n\nLink: ${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!artimimpi")){
const adam = text.replace(/!artimimpi /, "")
axios.get(`https://api.vhtear.com/artimimpi?query=${adam}&apikey=${vh}`).then((res) => {
    let hasil = `✅Jawaban nya ialah: ${res.data.result.hasil}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes("!wiki")){
const aris = text.replace(/!wiki /, "")
axios.get(`https://arugaz.herokuapp.com/api/wiki?q=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *👩‍💻Menurut Wikipedia:👩‍💻* \n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!wikien")){
const aris = text.replace(/!wikien /, "")
axios.get(`https://arugaz.herokuapp.com/api/wikien?q=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *👩‍💻According to Wikipedia:👩‍💻* \n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!spamgmail")){
const aris = text.replace(/!spamgmail /, "")
axios.get(`https://arugaz.herokuapp.com/api/spamgmail?target=${aris}&jum=1`).then((res) => {
    let hasil = `${res.data.logs}`;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}   
if (text.includes("!sholat")){
  const data = text.replace(/!sholat /, "")
  axios.get(`https://api.vhtear.com/jadwalsholat?query=${data}&apikey=${vh}`).then ((res) =>{
  conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
  let hasil = `Jadwal sholat di ${data} hari ini adalah\n\n⚡Kota : ${res.data.result.kota}\n⚡Subuh : ${res.data.result.Shubuh} WIB\n⚡Dzuhur : ${res.data.result.Zduhur}WIB\n⚡Ashar : ${res.data.result.Ashr} WIB\n⚡Maghrib : ${res.data.result.Magrib}\n⚡Isya : ${res.data.result.Isya} WIB\n⚡Tanggal : ${res.data.result.tanggal}`;
  conn.sendMessage(id, hasil, MessageType.text, { quoted: m });
})
}

else if (text == '!quran'){
axios.get('https://api.banghasan.com/quran/format/json/acak').then((res) => {
    const sr = /{(.*?)}/gi;
    const hs = res.data.acak.id.ayat;
    const ket = `${hs}`.replace(sr, '');
    let hasil = `[${ket}]   ${res.data.acak.ar.teks}\n\n${res.data.acak.id.teks}(QS.${res.data.surat.nama}, Ayat ${ket})`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!bitly")){
const aris = text.replace(/!bitly /, "")
axios.get(`https://tobz-api.herokuapp.com/api/shorturl?url=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = `nih kak :) \n\n${res.data.result}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
else if (text == '.opengc'){
let hasil = `${id.split("@s.whatsapp.net")[0]}`;
   conn.groupSettingChange (hasil, GroupSettingChange.messageSend, false);
conn.sendMessage(id, 'SUCCES, GRUP TELAH DIBUKA' ,MessageType.text, { quoted: m } );
}
else if (text == '.closegc'){
 let hasil = `${id.split("@s.whatsapp.net")[0]}`;
   conn.groupSettingChange (hasil, GroupSettingChange.messageSend, true);
conn.sendMessage(id, 'SUCCES, GRUP TELAH DITUTUP' ,MessageType.text, { quoted: m } );
}
if (text.includes("!setname")){
const teks = text.replace(/!setname /, "")
    let nama = `${teks}`;
    let idgrup = `${id.split("@s.whatsapp.net")[0]}`;
    conn.groupUpdateSubject(idgrup, nama);
conn.sendMessage(id, 'ADAM Telah mengganti nama Grub' ,MessageType.text, { quoted: m } );

}
if (text.includes("!setdesc")){
const teks = text.replace(/!setdesc /, "")
    let desk = `${teks}`;
    let idgrup = `${id.split("@s.whatsapp.net")[0]}`;
    conn.groupUpdateDescription(idgrup, desk)
conn.sendMessage(id, 'ADAM telah mrubah descripsi grup' ,MessageType.text, { quoted: m } );

}
if (text.includes('!tagme')) {
 var nomor = m.participant
 const options = {
       text: `@${nomor.split("@s.whatsapp.net")[0]} tagged!`,
       contextInfo: { mentionedJid: [nomor] }
 }
 conn.sendMessage(id, options, MessageType.text)
}
if (text.includes("!puisi1")){
const aris = text.replace(/!puisi1 /, "")
axios.get(`https://arugaz.herokuapp.com/api/puisi1`).then((res) => {
conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Nih Puisinya Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!puisi2")){
const aris = text.replace(/!puisi2 /, "")
axios.get(`https://arugaz.herokuapp.com/api/puisi3`).then((res) => {
conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Nih Puisinya Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!cerpen")){
const aris = text.replace(/!cerpen /, "")
axios.get(`https://arugaz.herokuapp.com/api/cerpen`).then((res) => {
conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *Nih cerpen Kak :)*\n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!spamcall")){
const aris = text.replace(/!spamcall /, "")
axios.get(`https://arugaz.herokuapp.com/api/spamcall?no=${aris}`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` *INFO SPAM CALL* \n\n _${res.data.logs}_`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!bucin")){
const aris = text.replace(/!bucin /, "")
axios.get(`https://arugaz.herokuapp.com/api/howbucins`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` _${res.data.desc}_ `;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes("!ttsid")){
const aris = text.replace(/!tts /, "")
axios.get(`http://scrap.terhambar.com/tts?kata=${aris}`).then((res) => {
	var aris = text.split("!ttsid ")[1];
  var path = require('path');
  var text1 = aris.slice(6);
  text1 = suara;
  var suara = text.replace(/!ttsid/g, text1);
  var filepath = 'mp3/bacot.wav';
  
  
/*
 * save audio file
 */

gtts.save(filepath, suara, function() {
  console.log(`${filepath} MP3 SAVED=`)
});
const buffer = fs.readFileSync(filepath)
	conn.sendMessage(id , buffer , MessageType.audio);

})
}
if (text.includes("!infoanime")){
const aris = text.replace(/!infoanime /, "")
axios.get(`https://arugaz.herokuapp.com/api/dewabatch?q=${aris}`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` *INFO ANIME ${aris} :* \n\n _${res.data.result}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!gay")){
const aris = text.replace(/!gay /, "")
axios.get(`https://arugaz.herokuapp.com/api/howgay`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` ${res.data.desc} \n\n *Persen Gay Lo!!!* _${res.data.persen}_`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}

if (text.includes('!movie')){
  var teks = text.replace(/!movie /, '')
    axios.get('https://arugaz.herokuapp.com/api/sdmovie?film='+teks)
    .then((res) => {
      imageToBase64(res.data.result.thumb)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image)
        })
    })
} 

if (text.includes('!memecreate')){
  var teks = text.replace(/!memecreate /, '')
    axios.get(`https://mnazria.herokuapp.com/api/create-meme?text-atas=${teks}`).then((res) => {
      imageToBase64(res.data.result)
        .then(
          (ress) => {
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { quoted: m })
        })
    })
}

if (text.includes('!samehadaku')){
  var teks = text.replace(/!samehadaku /, '')
    axios.get(`https://docs-jojo.herokuapp.com/api/samehadaku?q=${teks}`).then((res) => {
      imageToBase64(res.data.thumb)
        .then(
          (ress) => {
          	let hasil = `Anime Ditemukan!!\n\n* Nama :* ${res.data.title}\n* Sinopsis Dan Film :* ${res.data.link}`;
            var buf = Buffer.from(ress, 'base64')
            conn.sendMessage(id, buf, MessageType.image, { caption: hasil, quoted: m })
        })
    })
}


if (text.includes("!movie")){
const aris = text.replace(/!movie /, "")
axios.get(`https://arugaz.herokuapp.com/api/sdmovie?film=${aris}`).then((res) => {
	conn.sendMessage(id, '[WAIT] Proses...❗', MessageType.text)
    let hasil = ` *Film Anime ${aris} :* \n\n *Judul* _${res.data.result.title}_ \n\n *Rating* _${res.data.result.rating}_ \n\n *Info* _${res.data.result.sinopsis}_ `;
    conn.sendMessage(id, hasil ,MessageType.text);
})
}
if (text.includes("!covidID")){
const aris = text.replace(/!covid /, "")
axios.get(`https://arugaz.herokuapp.com/api/coronaindo`).then((res) => {
conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = ` *🔎DATA WABAH COVID-19 TERBARU DI INDONESIA🔍* \n\n *Kasus Baru* : _${res.data.kasus_baru}_ \n\n *Kasus Total* : _${res.data.kasus_total}_ \n\n *Meninggal* : _${res.data.meninggal}_ \n\n *Negara* : _${res.data.negara}_ \n\n *Penanganan* : _${res.data.penanganan}_ \n\n *Sembuh* : _${res.data.sembuh}_ \n\n *Terakhir* : _${res.data.terakhir}_ `;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text.includes("!ytmp4"))
   {
      const url = text.replace(/!ytmp4 /, "");
      const exec = require('child_process').exec;

      var videoid = url.match(/(?:https?:\/{2})?(?:w{3}\.)?youtu(?:be)?\.(?:com|be)(?:\/watch\?v=|\/)([^\s&]+)/);

      const ytdl = require("ytdl-core")
      if (videoid != null)
      {
         console.log("video id = ", videoid[1]);
      }
      else
      {
         conn.sendMessage(id, "maaf, link yang anda kirim tidak valid", MessageType.text)
      }
      ytdl.getInfo(videoid[1]).then(info =>
      {
         if (info.length_seconds > 1000)
         {
            conn.sendMessage(id, " videonya kepanjangan", MessageType.text)
         }
         else
         {

            console.log(info.length_seconds)

            function os_func()
            {
               this.execCommand = function (cmd)
               {
                  return new Promise((resolve, reject) =>
                  {
                     exec(cmd, (error, stdout, stderr) =>
                     {
                        if (error)
                        {
                           reject(error);
                           return;
                        }
                        resolve(stdout)
                     });
                  })
               }
            }
            var os = new os_func();

            os.execCommand('ytdl ' + url + ' -q highest -o mp4/' + videoid[1] + '.mp4').then(res =>
            {
		const buffer = fs.readFileSync("mp4/"+ videoid[1] +".mp4")
               conn.sendMessage(id, buffer, MessageType.video)
            }).catch(err =>
            {
               console.log("os >>>", err);
            })

         }
      });

   }
if (text.includes("!namaninja")){
const aris = text.replace(/!namaninja /, "")
axios.get(`https://api.terhambar.com/ninja?nama=${aris}`).then((res) => {
	conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
    let hasil = `Nama Ninja kamu🙂:\n\n${res.data.result.ninja}`;
    conn.sendMessage(id, hasil ,MessageType.text, { quoted: m });
})
}
if (text == '#help'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, aris.aris(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
if (text == '#menu'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, aris1.aris1(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}

else if (text == '#donate'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
else if (text == '#donasi'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
else if (text == '#DONATE'){
const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
else if (text == '#DONASI'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, donate.donate(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
else if (text == '#info'){
  const corohelp = await get.get('https://covid19.mathdro.id/api/countries/id').json()
var date = new Date();
var tahun = date.getFullYear();
var bulan = date.getMonth();
var tanggal = date.getDate();
var hari = date.getDay();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
switch(hari) {
 case 0: hari = "Minggu"; break;
 case 1: hari = "Senin"; break;
 case 2: hari = "Selasa"; break;
 case 3: hari = "Rabu"; break;
 case 4: hari = "Kamis"; break;
 case 5: hari = "Jum'at"; break;
 case 6: hari = "Sabtu"; break;
}
switch(bulan) {
 case 0: bulan = "Januari"; break;
 case 1: bulan = "Februari"; break;
 case 2: bulan = "Maret"; break;
 case 3: bulan = "April"; break;
 case 4: bulan = "Mei"; break;
 case 5: bulan = "Juni"; break;
 case 6: bulan = "Juli"; break;
 case 7: bulan = "Agustus"; break;
 case 8: bulan = "September"; break;
 case 9: bulan = "Oktober"; break;
 case 10: bulan = "November"; break;
 case 11: bulan = "Desember"; break;
}
var tampilTanggal = "TANGGAL: " + hari + ", " + tanggal + " " + bulan + " " + tahun;
var tampilWaktu = "JAM: " + jam + ":" + menit + ":" + detik;
conn.sendMessage(id, info.info(id, A187, corohelp, tampilTanggal, tampilWaktu, instagram, nomer, aktif, groupwhatsapp, youtube) ,MessageType.text);
}
else if (text == '!foto'){
conn.sendMessage(id, 'kirim !foto cewek/cowok\n\nContoh: !foto cewek' ,MessageType.text);
}
else if (text == '#help'){
conn.sendMessage(id, ' _🗣️Thanks Telah Menggunakan BOT *👾AR15BOT👾* , Follow Instagram Mimin Yah😻 : https://instagram.com/_sadboy.ig_' ,MessageType.text);
}
else if (text == '#menu'){
conn.sendMessage(id, ' _🗣️Thanks Telah Menggunakan BOT *👾AR15BOT👾* , Follow Instagram Mimin Yah😻 : https://instagram.com/_sadboy.ig_' ,MessageType.text);
}
   if (messageType == 'imageMessage')
   {
      let caption = imageMessage.caption.toLocaleLowerCase()
      const buffer = await conn.downloadMediaMessage(m) // to decrypt & use as a buffer
      if (caption == '!sticker')
      {
         const stiker = await conn.downloadAndSaveMediaMessage(m) // to decrypt & save to file

         const
         {
            exec
         } = require("child_process");
         exec('cwebp -q 50 ' + stiker + ' -o temp/' + jam + '.webp', (error, stdout, stderr) =>
         {
            let stik = fs.readFileSync('temp/' + jam + '.webp')
            conn.sendMessage(id, stik, MessageType.sticker)
         });
      }
   }

   if (messageType === MessageType.text)
   {
      let is = m.message.conversation.toLocaleLowerCase()

      if (is == '!pantun')
      {

         fetch('https://raw.githubusercontent.com/pajaar/grabbed-results/master/pajaar-2020-pantun-pakboy.txt')
            .then(res => res.text())
            .then(body =>
            {
               let tod = body.split("\n");
               let pjr = tod[Math.floor(Math.random() * tod.length)];
               let pantun = pjr.replace(/pjrx-line/g, "\n");
               conn.sendMessage(id, pantun, MessageType.text)
            });
      }

   }
 
   if (text.includes("!quotes2"))
   {
      var url = 'https://jagokata.com/kata-bijak/acak.html'
      axios.get(url)
         .then((result) =>
         {
            let $ = cheerio.load(result.data);
            var author = $('a[class="auteurfbnaam"]').contents().first().text();
            var kata = $('q[class="fbquote"]').contents().first().text();

            conn.sendMessage(
               id,
               `
_${kata}_
        
    
	*~${author}*
         `, MessageType.text
            );

         });
   }

   
   if (text.includes("!loli"))
   {
    var items = ["anime loli","anime loli sange","anime loli fackgirll","anime loli i love you"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
    
if (text.includes("!pokemon"))
   {
    var items = ["anime pokemon"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

if (text == ".ping") {
const speed = require("performance-now")
const timestamp = speed();
	const latensi = speed() - timestamp
	conn.sendMessage(id, `Speed ${latensi.toFixed(4)} Second`, MessageType.text, { quoted: m })
}

if (text.includes("!one piece"))
   {
    var items = ["anime one piece"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

if (text.includes("!black clover"))
   {
    var items = ["anime black clover"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

   else if (text.includes("!artinama")) 
  {
    const cheerio = require('cheerio');
    const request = require('request');
    var nama = text.split("!artinama ")[1];
    var req = nama.replace(/ /g,"+");
    request.get({
        headers: {'content-type' : 'application/x-www-form-urlencoded'},
        url:     'http://www.primbon.com/arti_nama.php?nama1='+ req +'&proses=+Submit%21+',
      },function(error, response, body){
          let $ = cheerio.load(body);
          var y = $.html().split('arti:')[1];
          var t = y.split('method="get">')[1];
          var f = y.replace(t ," ");
          var x = f.replace(/<br\s*[\/]?>/gi, "\n");
          var h  = x.replace(/<[^>]*>?/gm, '');
      console.log(""+ h);
      conn.sendMessage(id,
            `
      Arti dari nama *${nama}* adalah

❉──────────❉

         Nama _*${nama}*_ _${h}_
         
❉──────────❉

`,
 MessageType.text, { quoted: m });
  });
  }
  else if (text.includes("!pasangan ")) {
    const request = require('request');
    var gh = text.split("!pasangan ")[1];
    var namamu = gh.split("&")[0];
    var pasangan = gh.split("&")[1];
    request.get({
        headers: {'content-type' : 'application/x-www-form-urlencoded'},
        url:     'http://www.primbon.com/kecocokan_nama_pasangan.php?nama1='+ namamu +'&nama2='+ pasangan +'&proses=+Submit%21+',

    },function(error, response, body){
        let $ = cheerio.load(body);
      var y = $.html().split('<b>KECOCOKAN JODOH BERDASARKAN NAMA PASANGAN</b><br><br>')[1];
        var t = y.split('.<br><br>')[1];
        var f = y.replace(t ," ");
        var x = f.replace(/<br\s*[\/]?>/gi, "\n");
        var h  = x.replace(/<[^>]*>?/gm, '');
        var d = h.replace("&amp;", '&')
      console.log(""+ d);
      conn.sendMessage(id, `

❉──────────❉

 *Kecocokan berdasarkan nama*


 _${d}_


❉──────────❉
    `, MessageType.text, { quoted: m });
  });
  }
   if (text.includes("!foto cewek"))
   {
    var items = ["ullzang girl", "cewe cantik", "hijab cantik", "korean girl", "cewek rusia", "cewek korea", "cewek jepang"];
    var cewe = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cewe;
    
    axios.get(url)
      .then((result) => {
        var b = JSON.parse(JSON.stringify(result.data));
        var cewek =  b[Math.floor(Math.random() * b.length)];
        imageToBase64(cewek) // Path to the image
        .then(
            (response) => {
    conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
	var buf = Buffer.from(response, 'base64'); // Ta-da	
              conn.sendMessage(
            id,
              buf,MessageType.image)
       
            }
        )
        .catch(
            (error) => {
                console.log(error); // Logs an error if there was one
            }
        )
    
    });
    }

   if (text.includes("!foto cowok"))
   {
    var items = ["cowo ganteng", "cogan", "korean boy", "arabian boy", "japan boy", "cowok indo ganteng", "handsome boy"];
    var cowo = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + cowo;
    
    axios.get(url)
      .then((result) => {
        var z = JSON.parse(JSON.stringify(result.data));
        var cowok =  z[Math.floor(Math.random() * z.length)];
        imageToBase64(cowok) 
        .then(
            (response) => {
  conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
  var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }

if (text.includes("!fotoanime"))
   {
    var items = ["anime girl", "anime cantik", "anime", "anime aesthetic", "anime hd", "gambar anime hd"];
    var nime = items[Math.floor(Math.random() * items.length)];
    var url = "https://api.fdci.se/rep.php?gambar=" + nime;
    
    axios.get(url)
      .then((result) => {
        var n = JSON.parse(JSON.stringify(result.data));
        var nimek =  n[Math.floor(Math.random() * n.length)];
        imageToBase64(nimek) 
        .then(
            (response) => {
    conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
	var buf = Buffer.from(response, 'base64'); 
              conn.sendMessage(
            id,
              buf,MessageType.image, { quoted: m })
       
            }
        )
        .catch(
            (error) => {
                console.log(error);
            }
        )
    
    });
    }
else if (text == 'baka'){
let hasil = fs.readFileSync('mp3/' + 'baka' + '.wav')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m })
}
else if (text == 'sakit'){
let hasil = fs.readFileSync('mp3/' + 'sakit' + '.m4a')
 conn.sendMessage(id, hasil, MessageType.audio, { quoted: m })
}
if (text.includes("!lirik")){
	const aris = text.replace(/!lirik /, "")
	axios.get(`https://arugaz.herokuapp.com/api/lirik?judul=${aris}`).then ((res) => {
	     conn.sendMessage(id, '[❗] WAIT SEDANG DIPROSES', MessageType.text)
	 	let hasil = ` *🎧Lirik🎧 Lagu ${aris}:* \n\n\n _${res.data.result}_ `
	conn.sendMessage(id, hasil, MessageType.text, { quoted: m })
	})
}
if (text.includes("!alay")){
	const aris = text.replace(/!alay /, "")
	axios.get(`https://arugaz.herokuapp.com/api/bapakfont?kata=${aris}`).then ((res) =>
		{ let hasil = `${res.data.result}`
		conn.sendMessage(id, hasil, MessageType.text, { quoted: m })
	})
}

//Tolonglah bro jangan di ubah ubah Aris187 ID


})

